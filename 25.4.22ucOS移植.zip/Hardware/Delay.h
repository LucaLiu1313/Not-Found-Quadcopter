#ifndef __DELAY_H
#define __DELAY_H
#include <stdint.h>

void Delay_us(uint16_t time);

void Delay_ms(uint16_t time);

#endif
