#ifndef HARDWAREINIT_H
#define HARDWAREINIT_H


void GPIO_INIT(void);
void hardware_Init(void);

int16_t AX,AY,AZ,GX,GY,GZ,GH;
int16_t  X , Y , Z,GaX;
int32_t Pressure;
int16_t MX,MY,MZ;

#endif

